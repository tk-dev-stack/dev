export const gridStyles = `
  inputField: 
    .inputField {
      
    }
  ,
  container: 
    .container {
    border: 1px solid lightgray;
    padding: 20px;
    margin: 20px;
    border-radius: 20px;
    }
  ,
  buttonStyle: 
    .buttonStyle {
     
    }
    ,
`;
