export interface WidgetData {
  id: number;
  name: string;
  value: string;
}
