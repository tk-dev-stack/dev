export const sampleApi = "https://jsonplaceholder.typicode.com/users/1";
